`timescale 1ns/1ps
`include "noc_defines.vh"

// -----------------------------------------------------------------------------
// V2 performance monitor.
//
// Simulation/evaluation infrastructure only.
// It is deliberately outside the frozen DUT.
//
// Transaction identity:
//   payload[31:0] is used as a unique experiment transaction ID.
//
// Measurements:
//   - packets injected
//   - packets received
//   - packet loss/unmatched receive
//   - min/max/average latency
//   - min/max/average hybrid hop count
//   - aggregate throughput
//
// A performance experiment MUST use a unique payload ID for every outstanding
// packet. This keeps matching deterministic even when several packets from
// one source are simultaneously in flight.
// -----------------------------------------------------------------------------
module noc_v2_metrics_monitor #(
    parameter MAX_INFLIGHT = 1024
)
(
    input clk,
    input rst,

    input [63:0] inject_event,
    input [63:0] receive_event,

    // Flattened 64×48-bit buses for Verilog-2001/Vivado compatibility.
    // Packet i occupies bits [48*i +: 48].
    input [64*`PACKET_WIDTH-1:0] inject_packet_bus,
    input [64*`PACKET_WIDTH-1:0] receive_packet_bus,

    output reg [31:0] packets_injected,
    output reg [31:0] packets_received,
    output reg [31:0] unmatched_receives,

    output reg [63:0] total_latency,
    output reg [63:0] min_latency,
    output reg [63:0] max_latency,

    output reg [63:0] total_hops,
    output reg [31:0] min_hops,
    output reg [31:0] max_hops,

    output reg [63:0] experiment_cycles
);

    reg                 slot_valid [0:MAX_INFLIGHT-1];
    reg [31:0]          slot_id    [0:MAX_INFLIGHT-1];
    reg [63:0]          slot_time  [0:MAX_INFLIGHT-1];
    reg [3:0]           slot_hops  [0:MAX_INFLIGHT-1];

    integer i;
    integer j;
    integer free_slot;
    integer match_slot;

    reg [63:0] cycle_count;
    reg [63:0] latency_now;
    reg [3:0]  hops_now;
    reg        found_free;
    reg        found_match;

    function [3:0] calc_hops;
        input [1:0] sc;
        input [1:0] sr;
        input [1:0] scol;
        input [1:0] dc;
        input [1:0] dr;
        input [1:0] dcol;
        integer a;
        integer b;
        integer c;
        integer d;
        begin
            if (sc == dc)
            begin
                a = sr - dr;
                if (a < 0) a = -a;
                b = scol - dcol;
                if (b < 0) b = -b;
                calc_hops = a + b;
            end
            else
            begin
                // V2 gateway is R0=(0,0). One global-network transfer.
                c = sr;
                d = scol;
                a = dr;
                b = dcol;
                calc_hops = c + d + 1 + a + b;
            end
        end
    endfunction

    always @(posedge clk or posedge rst)
    begin
        if (rst)
        begin
            packets_injected   <= 0;
            packets_received   <= 0;
            unmatched_receives <= 0;

            total_latency <= 0;
            min_latency   <= 64'hFFFF_FFFF_FFFF_FFFF;
            max_latency   <= 0;

            total_hops <= 0;
            min_hops   <= 32'hFFFF_FFFF;
            max_hops   <= 0;

            experiment_cycles <= 0;
            cycle_count <= 0;

            for (i = 0; i < MAX_INFLIGHT; i = i + 1)
            begin
                slot_valid[i] <= 1'b0;
                slot_id[i]    <= 0;
                slot_time[i]  <= 0;
                slot_hops[i]  <= 0;
            end
        end
        else
        begin
            cycle_count <= cycle_count + 1'b1;
            experiment_cycles <= cycle_count;

            // -------------------------------------------------------------
            // Record injections.
            // Multiple source events may occur in one cycle.
            // -------------------------------------------------------------
            for (i = 0; i < 64; i = i + 1)
            begin
                if (inject_event[i])
                begin
                    found_free = 1'b0;
                    free_slot = -1;

                    for (j = 0; j < MAX_INFLIGHT; j = j + 1)
                    begin
                        if (!found_free && !slot_valid[j])
                        begin
                            found_free = 1'b1;
                            free_slot = j;
                        end
                    end

                    if (found_free)
                    begin
                        slot_valid[free_slot] <= 1'b1;
                        slot_id[free_slot] <=
                            inject_packet_bus[
                                i*`PACKET_WIDTH + 31 -: 32
                            ];

                        slot_time[free_slot] <= cycle_count;

                        slot_hops[free_slot] <= calc_hops(
                            inject_packet_bus[
                                i*`PACKET_WIDTH + 41 -: 2
                            ],
                            inject_packet_bus[
                                i*`PACKET_WIDTH + 39 -: 2
                            ],
                            inject_packet_bus[
                                i*`PACKET_WIDTH + 37 -: 2
                            ],
                            inject_packet_bus[
                                i*`PACKET_WIDTH + 47 -: 2
                            ],
                            inject_packet_bus[
                                i*`PACKET_WIDTH + 45 -: 2
                            ],
                            inject_packet_bus[
                                i*`PACKET_WIDTH + 43 -: 2
                            ]
                        );

                        packets_injected <= packets_injected + 1'b1;
                    end
                end
            end

            // -------------------------------------------------------------
            // Match receives by unique payload ID.
            // -------------------------------------------------------------
            for (i = 0; i < 64; i = i + 1)
            begin
                if (receive_event[i])
                begin
                    found_match = 1'b0;
                    match_slot = -1;

                    for (j = 0; j < MAX_INFLIGHT; j = j + 1)
                    begin
                        if (!found_match &&
                            slot_valid[j] &&
                            slot_id[j] ==
                            receive_packet_bus[
                                i*`PACKET_WIDTH + 31 -: 32
                            ])
                        begin
                            found_match = 1'b1;
                            match_slot = j;
                        end
                    end

                    if (found_match)
                    begin
                        latency_now =
                            cycle_count - slot_time[match_slot];

                        hops_now = slot_hops[match_slot];

                        packets_received <=
                            packets_received + 1'b1;

                        total_latency <=
                            total_latency + latency_now;

                        total_hops <=
                            total_hops + hops_now;

                        if (latency_now < min_latency)
                            min_latency <= latency_now;

                        if (latency_now > max_latency)
                            max_latency <= latency_now;

                        if (hops_now < min_hops)
                            min_hops <= hops_now;

                        if (hops_now > max_hops)
                            max_hops <= hops_now;

                        slot_valid[match_slot] <= 1'b0;
                    end
                    else
                    begin
                        unmatched_receives <=
                            unmatched_receives + 1'b1;
                    end
                end
            end
        end
    end

endmodule
